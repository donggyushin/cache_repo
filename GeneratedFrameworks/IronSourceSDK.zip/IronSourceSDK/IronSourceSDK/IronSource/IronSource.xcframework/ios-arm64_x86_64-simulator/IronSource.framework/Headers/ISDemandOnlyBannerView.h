//
//  ISDemandOnlyBannerView.h
//  IronSource
//
//  Created by Ariel Barsheshet on 23/08/2022.
//  Copyright © 2022 IronSource. All rights reserved.
//

#import <UIKit/UIKit.h>

#ifndef ISDemandOnlyBannerView_h
#define ISDemandOnlyBannerView_h

@interface ISDemandOnlyBannerView : UIView
@end


#endif /* ISDemandOnlyBannerView_h */
