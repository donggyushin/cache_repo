//
//  PAGGeckoPreloadManager.h
//  BUAdSDK
//
//  Created by wangyanlin on 2020/6/29.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const kPAGGeckoInitDoneNotificationName;

typedef void (^PAGPreloadCompletion)(NSData * _Nullable data,NSDictionary * _Nullable respHeader);
typedef void (^PAGPreloadTrackBlock)(NSObject *model,NSString *label,NSDictionary *parameter);
typedef void (^PAGSyncDataCompletion)(BOOL success,NSDictionary *info);
@interface PAGGeckoPreloadManager : NSObject

@property (nonatomic, strong) NSMapTable *mapTable;

@property (nonatomic, strong) NSMutableDictionary *geckoDict;

@property (nonatomic, copy) PAGPreloadTrackBlock trackBlock;

+ (instancetype)sharedInstance;

+ (void)setupSDKWithTerritory:(NSString *)territory
                     IESGeckoKitAppId:(NSString *)IESGeckoKitAppId
          IESGeckoKit_CACHE_DIRECTORY:(NSString *)IESGeckoKit_CACHE_DIRECTORY
                 IESGeckoKitAccessKey:(NSString *)IESGeckoKitAccessKey
                  IESGeckoKit_Domains:(NSArray *)IESGeckoKit_Domains
                             ZipBlock:(id)zipBlock;

//1.本地zip 包已经被删除了,自动去下载
//2.如果zip需要更新,会自动更新
//3.本地有zip, 并且不需要更新. 不做处理
+ (void)syncResourcesParamsWithChannel:(NSArray <id>*)materialArray hosts:(NSArray *)hosts;

+ (BOOL)geckoDidSetup;
+ (void)registAccessKey:(NSString *)ak;
+ (void)setGeckoDeviceID:(NSString *)deviceID;
+ (void)syncResourcesParamsWithAccessKey:(NSString *)ak
                                channels:(NSArray<NSString *> *)channelIds
                                   hosts:(NSArray *)hosts
                              completion:(PAGSyncDataCompletion _Nullable)completion;

+ (void)asyncGetDataWithInfo:(NSDictionary *)info
                   accessKey:(NSString *)ak
                     channel:(NSString *)channel
                  completion:(PAGPreloadCompletion)completion;

+ (void)asyncGetDataWithInfo:(NSDictionary *)info completion:(PAGPreloadCompletion)completion;

+ (void)loadResourceToMemoryWithAccessKey:(NSString *)accessKey channel:(NSString *)channel;

@end

/// 上面封装的代码和业务耦合太大，没有独立性。下面的是直接调用 Gecko 原始方法的转接

@interface PAGGeckoPreloadManager (PassThrough)

/**
 * @brief 读取缓存数据
 */
+ (nullable NSData *)dataForPath:(NSString *)path accessKey:(NSString *)accessKey channel:(NSString *)channel;

/**
* @brief 异步读取缓存数据
*/
+ (void)asyncGetDataForPath:(NSString *)path
                  accessKey:(NSString *)accessKey
                    channel:(NSString *)channel
                 completion:(void (^)(NSData * _Nullable data))completion;

/**
* @brief 返回文件版本；如果文件未激活，则返回0
*/
+ (uint64_t)packageVersionForAccessKey:(NSString *)accessKey channel:(NSString *)channel;

/**
 * @brief 获取指定accessKey根目录
 */
+ (NSString *)rootDirForAccessKey:(NSString *)accessKey;

/**
 * @brief 获取指定channel根目录
 */
+ (NSString *)rootDirForAccessKey:(NSString *)accessKey channel:(NSString *)channel;

@end

NS_ASSUME_NONNULL_END
