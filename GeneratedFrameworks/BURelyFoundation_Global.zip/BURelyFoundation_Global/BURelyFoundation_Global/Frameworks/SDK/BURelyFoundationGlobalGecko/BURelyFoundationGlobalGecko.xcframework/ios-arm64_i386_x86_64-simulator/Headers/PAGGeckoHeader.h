//
//  BU_Gecko.h
//  Pods
//
//  Created by zth on 2022/5/27.
//

#ifndef PAG_Gecko_h
#define PAG_Gecko_h

#import "PAGGeckoPreloadManager.h"


#endif /* PAG_Gecko_h */
